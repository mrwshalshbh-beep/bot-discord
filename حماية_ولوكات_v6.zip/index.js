// Copyright (c) 2026 CS. All rights reserved.
const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const config = require('./config.js');

// ================= حماية حقوق الملكية =================
const copyrightText = '// Copyright (c) 2026 CS. All rights reserved.';
const dirsToCheck = [__dirname, path.join(__dirname, 'commands'), path.join(__dirname, 'events'), path.join(__dirname, 'utils')];

for (const dir of dirsToCheck) {
    if (!fs.existsSync(dir)) continue;
    const files = fs.readdirSync(dir).filter(f => f.endsWith('.js') && f !== 'config.js');
    for (const file of files) {
        const fullPath = path.join(dir, file);
        if (fs.statSync(fullPath).isFile()) {
            const content = fs.readFileSync(fullPath, 'utf8');
            if (!content.includes(copyrightText)) {
                console.error(`\x1b[31m[خطأ] تم العبث بحقوق الملكية في: ${file}\x1b[0m`);
                process.exit(1);
            }
        }
    }
}

console.log(`\x1b[36m
   _____   _____  
  / ____| / ____| 
 | |     | (___   
 | |      \\___ \\  
 | |____  ____) | 
  \\_____||_____/  
\x1b[0m`);
console.log(`\x1b[33m[CS System] قناة يوتيوب: https://www.youtube.com/@cs_discord\x1b[0m\n`);
// ========================================================

// الاتصال بـ MongoDB في الخلفية — لا يوقف تشغيل البوت
const db = require('./utils/database.js');
db.connect(config.mongoUri);

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildPresences,
        GatewayIntentBits.GuildBans,
        GatewayIntentBits.GuildEmojisAndStickers,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.GuildWebhooks,
        GatewayIntentBits.GuildModeration,
    ],
    partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User, Partials.GuildMember]
});

client.commands = new Collection();

// تحميل الأوامر
const commandsPath = path.join(__dirname, 'commands');
if (!fs.existsSync(commandsPath)) fs.mkdirSync(commandsPath);
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    try {
        const command = require(`./commands/${file}`);
        client.commands.set(command.data.name, command);
        console.log(`\x1b[32m[CS System] ✅ أمر: ${command.data.name}\x1b[0m`);
    } catch (e) {
        console.error(`\x1b[31m[CS System] خطأ في تحميل الأمر ${file}:\x1b[0m`, e.message);
    }
}

// تحميل الأحداث
const eventsPath = path.join(__dirname, 'events');
if (!fs.existsSync(eventsPath)) fs.mkdirSync(eventsPath);
const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
for (const file of eventFiles) {
    try {
        const event = require(`./events/${file}`);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
    } catch (e) {
        console.error(`\x1b[31m[CS System] خطأ في تحميل الحدث ${file}:\x1b[0m`, e.message);
    }
}

console.log(`\x1b[33m[CS System] تم تحميل ${commandFiles.length} أمر و ${eventFiles.length} حدث — جاري الاتصال بديسكورد...\x1b[0m`);

client.login(config.token).catch(err => {
    console.error('\x1b[31m[CS System] فشل تسجيل الدخول — تحقق من التوكن:\x1b[0m', err.message);
    process.exit(1);
});
