// Copyright (c) 2026 CS. All rights reserved.
const fs = require('fs');
const path = require('path');

module.exports = {
    getSettings: () => {
        const filePath = path.join(__dirname, '../config.js');
        delete require.cache[require.resolve(filePath)];
        return require(filePath);
    },
    setSettings: (data) => {
        const filePath = path.join(__dirname, '../config.js');
        const content = `module.exports = ${JSON.stringify(data, null, 4)};\n`;
        fs.writeFileSync(filePath, content);
    },
    getWebhooks: () => {
        const filePath = path.join(__dirname, '../config/webhooks.json');
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    },
    setWebhooks: (data) => {
        const filePath = path.join(__dirname, '../config/webhooks.json');
        fs.writeFileSync(filePath, JSON.stringify(data, null, 4));
    },
    getLang: () => {
        const filePath = path.join(__dirname, '../config/lang.json');
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }
};
