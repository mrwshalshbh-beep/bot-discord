// Copyright (c) 2026 CS. All rights reserved.
const { EmbedBuilder, WebhookClient } = require('discord.js');
const { getWebhooks } = require('./config.js');

module.exports = {
    sendLog: async (client, guildId, logType, embedInfo) => {
        const webhooks = getWebhooks();
        const webhookUrl = webhooks[logType];

        if (!webhookUrl || typeof webhookUrl !== 'string' || !webhookUrl.startsWith('https://discord.com/api/webhooks/')) {
            return;
        }

        try {
            const webhookClient = new WebhookClient({ url: webhookUrl });

            // جلب إعدادات البوت لصور GIF
            let gifUrl = '';
            try {
                const config = require('../config.js');
                gifUrl = config.gifs?.[logType] || config.gifs?.default || '';
            } catch (e) {}

            const embed = new EmbedBuilder()
                .setColor(embedInfo.color || '#FFD700')
                .setTimestamp()
                .setFooter({ text: '© 2026 CS. جميع الحقوق محفوظة | CS System', iconURL: client.user?.displayAvatarURL() || null });

            if (embedInfo.author) embed.setAuthor(embedInfo.author);
            if (embedInfo.title) embed.setTitle(embedInfo.title);
            if (embedInfo.description) embed.setDescription(embedInfo.description);
            if (embedInfo.fields) embed.addFields(embedInfo.fields);
            if (embedInfo.thumbnail) embed.setThumbnail(embedInfo.thumbnail);
            // GIF كصورة رئيسية في الإيمبيد (من الكونفيج، أو من embedInfo مباشرة)
            const imageUrl = embedInfo.image || gifUrl;
            if (imageUrl) embed.setImage(imageUrl);

            await webhookClient.send({
                username: 'CS نظام السجلات',
                avatarURL: client.user?.displayAvatarURL() || null,
                embeds: [embed]
            });
        } catch (e) {
            console.error(`خطأ في إرسال السجل إلى الويب هوك [${logType}]:`, e);
        }
    }
};
