// Copyright (c) 2026 CS. All rights reserved.
const { AuditLogEvent } = require('discord.js');

const wait = (ms) => new Promise(r => setTimeout(r, ms));

/**
 * يجلب منفّذ العملية الأخيرة من سجل التدقيق بعد تأخير بسيط
 * @param {Guild} guild
 * @param {AuditLogEvent} type
 * @param {string|null} targetId - ID العنصر المستهدف (رتبة، قناة، عضو...)
 * @param {number} delay - تأخير بالملّي ثانية قبل الجلب (افتراضي 1200)
 * @returns {User|null}
 */
async function getExecutor(guild, type, targetId = null, delay = 1200) {
    await wait(delay);
    try {
        const logs = await guild.fetchAuditLogs({ limit: 5, type });
        const entry = logs.entries.find(e => {
            if (targetId) return e.target?.id === targetId;
            return true;
        });
        if (!entry) return null;
        // تأكد أن الحدث حديث (خلال 10 ثواني)
        if (Date.now() - entry.createdTimestamp > 10000) return null;
        return entry.executor;
    } catch (e) {
        console.error(`[CS] فشل جلب سجل التدقيق (${AuditLogEvent[type] ?? type}):`, e.message);
        return null;
    }
}

module.exports = { getExecutor, wait };
