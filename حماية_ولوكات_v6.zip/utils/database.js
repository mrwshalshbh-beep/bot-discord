// Copyright (c) 2026 CS. All rights reserved.
const mongoose = require('mongoose');

// ===== Schema =====
const bypassSchema = new mongoose.Schema({
    guildId:  { type: String, required: true },
    userId:   { type: String, required: true },
    feature:  { type: String, required: true },
    addedBy:  { type: String, required: true },
    addedAt:  { type: Date, default: Date.now }
});
bypassSchema.index({ guildId: 1, userId: 1, feature: 1 }, { unique: true });
const Bypass = mongoose.models.Bypass || mongoose.model('Bypass', bypassSchema);

// ===== الاتصال بـ MongoDB =====
let dbReady = false;

async function connect(uri) {
    if (!uri || uri === 'YOUR_MONGODB_URI_HERE' || uri.trim() === '') {
        console.warn('\x1b[33m[CS System] ⚠️  mongoUri غير مضبوط في config.js — ميزة التخطي معطّلة حتى تضبطه.\x1b[0m');
        return;
    }
    try {
        await mongoose.connect(uri, { serverSelectionTimeoutMS: 10000 });
        dbReady = true;
        console.log('\x1b[32m[CS System] ✅ تم الاتصال بـ MongoDB بنجاح\x1b[0m');
    } catch (e) {
        console.error('\x1b[31m[CS System] ❌ فشل الاتصال بـ MongoDB:\x1b[0m', e.message);
        console.warn('\x1b[33m[CS System] ⚠️  ميزة التخطي ستكون معطّلة. البوت سيعمل بدونها.\x1b[0m');
    }
}

// يُستدعى من index.js بعد تحميل الكونفيج
module.exports = {
    connect,
    isReady: () => dbReady,

    addBypass: async (guildId, userId, feature, addedBy) => {
        if (!dbReady) return false;
        try {
            await Bypass.updateOne(
                { guildId, userId, feature },
                { $set: { addedBy, addedAt: new Date() } },
                { upsert: true }
            );
            return true;
        } catch (e) { return false; }
    },

    removeBypass: async (guildId, userId, feature) => {
        if (!dbReady) return;
        await Bypass.deleteOne({ guildId, userId, feature });
    },

    removeAllBypasses: async (guildId, userId) => {
        if (!dbReady) return;
        await Bypass.deleteMany({ guildId, userId });
    },

    isBypassed: async (guildId, userId, feature) => {
        if (!dbReady) return false;
        const doc = await Bypass.findOne({
            guildId, userId,
            feature: { $in: [feature, 'all'] }
        }).lean();
        return !!doc;
    },

    getUserBypasses: async (guildId, userId) => {
        if (!dbReady) return [];
        const docs = await Bypass.find({ guildId, userId }).lean();
        return docs.map(d => d.feature);
    },

    getAllBypasses: async (guildId) => {
        if (!dbReady) return [];
        return await Bypass.find({ guildId }).sort({ addedAt: -1 }).lean();
    }
};
