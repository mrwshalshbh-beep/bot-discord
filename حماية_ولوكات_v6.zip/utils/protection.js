// Copyright (c) 2026 CS. All rights reserved.
const { getSettings, getLang } = require('./config.js');
const { sendLog } = require('./logger.js');
const db = require('./database.js');

const batchMap = new Map();
const BATCH_WINDOW = 1500;

async function punishExecutor(guild, executor) {
    try {
        const member = await guild.members.fetch(executor.id).catch(() => null);
        if (!member) return;
        if (member.user.bot) {
            await member.kick('حماية Anti-Nuke — بوت مشبوه').catch(() => {});
        } else {
            const rolesToRemove = member.roles.cache.filter(r => r.id !== guild.id && r.editable);
            for (const [, role] of rolesToRemove) {
                await member.roles.remove(role, 'حماية Anti-Nuke — تصفير الرتب').catch(() => {});
            }
        }
    } catch (e) {}
}

module.exports = {
    handleProtection: async (client, guild, actionName, featureKey, executor, details, revertAction) => {
        const settings = getSettings();
        if (!settings.protectionEnabled) return false;
        if (executor.id === client.user.id) return false;
        if (settings.owners.includes(executor.id)) return false;

        // تحقق من قائمة التخطي (async)
        if (await db.isBypassed(guild.id, executor.id, featureKey)) return false;

        const lang = getLang();

        try { await revertAction(); } catch (e) {
            console.error(`فشل التراجع عن "${actionName}":`, e);
        }

        const key = `${guild.id}:${executor.id}`;
        if (!batchMap.has(key)) {
            batchMap.set(key, {
                actions: [],
                timer: setTimeout(async () => {
                    batchMap.delete(key);
                    await punishExecutor(guild, executor);
                }, BATCH_WINDOW)
            });
        }
        batchMap.get(key).actions.push(actionName);

        const alertMsg = lang.protection_alert_desc
            .replace('{action}', actionName)
            .replace('{executor}', `${executor.tag} (${executor.id})`)
            .replace('{details}', details);

        for (const ownerId of settings.owners) {
            try {
                const owner = await client.users.fetch(ownerId);
                await owner.send(`**${lang.protection_alert_title}**\n${alertMsg}`);
            } catch (e) {}
        }

        await sendLog(client, guild.id, 'protectionLog', {
            title: lang.protection_alert_title,
            description: alertMsg,
            color: '#ff0000'
        });

        return true;
    }
};
