module.exports = {
    "token": "YOUR_BOT_TOKEN_HERE",           // توكن بوتك
    "mainGuildId": "YOUR_MAIN_SERVER_ID",      // id السيرفر الأساسي
    "logGuildId": "YOUR_LOG_SERVER_ID",        // id سيرفر اللوج
    "owners": [
        "YOUR_DISCORD_ID_HERE"                 // id الأونر
    ],
    "protectionEnabled": false,                // الحماية - تفعّل من الأمر /الحماية
    "mongoUri": "YOUR_MONGODB_URI_HERE",       // رابط MongoDB مثال: mongodb+srv://user:pass@cluster.mongodb.net/botdb
    "voiceChannelId": "YOUR_VOICE_CHANNEL_ID", // id القناة الصوتية (اتركها "" لإيقاف الميزة)

    // ===== صور متحركة GIF لكل نوع سجل =====
    // ضع رابط GIF مباشر — اتركه "" لإيقاف الصورة لذلك النوع
    "gifs": {
        "default":    "",   // GIF افتراضي
        "protection": "",   // سجل الحماية Anti-Nuke
        "roleLog":    "",   // سجل الرتب
        "channelLog": "",   // سجل القنوات
        "memberLog":  "",   // سجل الأعضاء
        "serverLog":  "",   // سجل إعدادات السيرفر
        "voiceLog":   "",   // سجل الصوت
        "threadLog":  "",   // سجل المواضيع
        "emojiLog":   "",   // سجل الإيموجي
        "banLog":     "",   // سجل الباندات
        "messageLog": "",   // سجل الرسائل
        "bypassLog":  ""    // سجل عمليات التخطي
    }
};
