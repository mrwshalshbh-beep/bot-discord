// Copyright (c) 2026 CS. All rights reserved.
const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const { getSettings, getLang } = require('../utils/config.js');

// تخزين مؤقت للـ URL المدخل حتى يختار المستخدم نوع السجل
const pendingWebhooks = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ضبط_الويب_هوك')
        .setDescription('تعيين رابط ويب هوك لنوع معين من السجلات (للأونرات فقط).')
        .addStringOption(option =>
            option.setName('الرابط')
                .setDescription('رابط الويب هوك من ديسكورد')
                .setRequired(true)
        ),

    async execute(interaction, client) {
        const settings = getSettings();
        const lang = getLang();

        if (!settings.owners.includes(interaction.user.id)) {
            return interaction.reply({ content: lang.no_permission, ephemeral: true });
        }

        const webhookUrl = interaction.options.getString('الرابط');

        if (!webhookUrl.startsWith('https://discord.com/api/webhooks/')) {
            return interaction.reply({ content: lang.invalid_webhook, ephemeral: true });
        }

        // حفظ الـ URL مؤقتاً
        pendingWebhooks.set(interaction.user.id, webhookUrl);
        setTimeout(() => pendingWebhooks.delete(interaction.user.id), 60000);

        const embed = new EmbedBuilder()
            .setTitle('🔗 تعيين ويب هوك')
            .setDescription(`تم استلام الرابط ✅\n\nاختر الآن **نوع السجل** الذي تريد ربطه بهذا الويب هوك:`)
            .setColor('#3498db')
            .setFooter({ text: 'ستنتهي هذه القائمة خلال 60 ثانية', iconURL: client.user?.displayAvatarURL() || null });

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('webhook_type_select')
            .setPlaceholder('اختر نوع السجل...')
            .addOptions([
                { label: '💬 سجل الرسائل', description: 'حذف وتعديل الرسائل', value: 'messageLog', emoji: '💬' },
                { label: '👥 سجل الأعضاء', description: 'انضمام ومغادرة الأعضاء', value: 'memberLog', emoji: '👥' },
                { label: '🎭 سجل الرتب', description: 'إنشاء وحذف وتعديل الرتب', value: 'roleLog', emoji: '🎭' },
                { label: '📢 سجل القنوات', description: 'إنشاء وحذف وتعديل القنوات', value: 'channelLog', emoji: '📢' },
                { label: '⚙️ سجل السيرفر', description: 'تعديلات إعدادات السيرفر', value: 'serverLog', emoji: '⚙️' },
                { label: '🎙️ سجل الصوت', description: 'دخول ومغادرة قنوات الصوت', value: 'voiceLog', emoji: '🎙️' },
                { label: '🧵 سجل المواضيع', description: 'إنشاء وحذف المواضيع', value: 'threadLog', emoji: '🧵' },
                { label: '😀 سجل الإيموجي', description: 'إنشاء وحذف وتعديل الإيموجي', value: 'emojiLog', emoji: '😀' },
                { label: '🔨 سجل الباندات', description: 'حظر ورفع حظر الأعضاء', value: 'banLog', emoji: '🔨' },
                { label: '🛡️ سجل الحماية', description: 'أحداث الحماية Anti-Nuke', value: 'protectionLog', emoji: '🛡️' }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    },

    getPendingWebhooks: () => pendingWebhooks
};
