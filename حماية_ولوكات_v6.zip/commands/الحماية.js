// Copyright (c) 2026 CS. All rights reserved.
const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const { getSettings, getLang } = require('../utils/config.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('الحماية')
        .setDescription('إدارة نظام الحماية Anti-Nuke (للأونرات فقط).'),

    async execute(interaction, client) {
        const settings = getSettings();
        const lang = getLang();

        if (!settings.owners.includes(interaction.user.id)) {
            return interaction.reply({ content: lang.no_permission, ephemeral: true });
        }

        const embed = new EmbedBuilder()
            .setTitle('🛡️ نظام الحماية Anti-Nuke')
            .setDescription(
                `**الحالة الحالية:** ${settings.protectionEnabled ? '🟢 مفعّل' : '🔴 موقوف'}\n\n` +
                `عند تفعيل الحماية، أي تعديل غير مصرح به (حذف رومات، تعديل رتب، تغيير صلاحيات...) سيتم التراجع عنه فوراً وتطبيق العقوبة على الفاعل.\n\n` +
                `**عقوبة الأعضاء:** تصفير الرتب\n` +
                `**عقوبة البوتات:** كيك من السيرفر`
            )
            .setColor(settings.protectionEnabled ? '#00FF00' : '#FF0000')
            .setFooter({ text: '© 2026 CS. جميع الحقوق محفوظة', iconURL: client.user?.displayAvatarURL() || null });

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('protection_select')
            .setPlaceholder('اختر إجراء...')
            .addOptions([
                {
                    label: '✅ تفعيل الحماية',
                    description: 'تفعيل نظام الحماية Anti-Nuke',
                    value: 'protection_on',
                    emoji: '🛡️'
                },
                {
                    label: '❌ إيقاف الحماية',
                    description: 'إيقاف نظام الحماية Anti-Nuke',
                    value: 'protection_off',
                    emoji: '🔓'
                }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    }
};
