// Copyright (c) 2026 CS. All rights reserved.
const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { getSettings } = require('../utils/config.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('المساعدة')
        .setDescription('عرض جميع الأوامر المتاحة في البوت.'),

    async execute(interaction, client) {
        const settings = getSettings();
        const isOwner = settings.owners.includes(interaction.user.id);

        const embed = new EmbedBuilder()
            .setTitle('🤖 أوامر البوت')
            .setColor('#3498db')
            .setDescription('قائمة بجميع الأوامر المتاحة:')
            .setThumbnail(client.user?.displayAvatarURL() || null)
            .setFooter({ text: '© 2026 CS. جميع الحقوق محفوظة | CS System', iconURL: client.user?.displayAvatarURL() || null });

        if (isOwner) {
            embed.addFields(
                {
                    name: '🛡️ `/الحماية`',
                    value: 'تفعيل أو إيقاف نظام الحماية Anti-Nuke مع قائمة تفاعلية.'
                },
                {
                    name: '🔗 `/ضبط_الويب_هوك`',
                    value: 'تعيين رابط ويب هوك لنوع معين من السجلات بقائمة تفاعلية.'
                },
                {
                    name: '📋 أنواع السجلات المتاحة:',
                    value: '> سجل الرسائل · سجل الأعضاء · سجل الرتب · سجل القنوات\n> سجل السيرفر · سجل الصوت · سجل المواضيع · سجل الإيموجي\n> سجل الباندات · سجل الحماية'
                }
            );
        } else {
            embed.addFields({
                name: '🔒 لا توجد أوامر عامة',
                value: 'هذا البوت مخصص للحماية والسجلات فقط. لا توجد أوامر متاحة للعامة.'
            });
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    }
};
