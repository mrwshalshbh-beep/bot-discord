// Copyright (c) 2026 CS. All rights reserved.
const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, EmbedBuilder } = require('discord.js');
const { getSettings, getLang } = require('../utils/config.js');
const db = require('../utils/database.js');

const FEATURES = [
    { label: '🛡️ كل الميزات',       description: 'تخطي جميع أنواع الحماية',                 value: 'all',           emoji: '🛡️' },
    { label: '➕ إنشاء رتبة',        description: 'تخطي حماية إنشاء الرتب',                   value: 'roleCreate',    emoji: '🎭' },
    { label: '🗑️ حذف رتبة',         description: 'تخطي حماية حذف الرتب',                    value: 'roleDelete',    emoji: '🗑️' },
    { label: '✏️ تعديل رتبة',        description: 'تخطي حماية تعديل الرتب والصلاحيات',        value: 'roleUpdate',    emoji: '✏️' },
    { label: '📢 إنشاء قناة',        description: 'تخطي حماية إنشاء القنوات',                 value: 'channelCreate', emoji: '📢' },
    { label: '🔇 حذف قناة',          description: 'تخطي حماية حذف القنوات',                   value: 'channelDelete', emoji: '🔇' },
    { label: '🔧 تعديل قناة',        description: 'تخطي حماية تعديل القنوات',                 value: 'channelUpdate', emoji: '🔧' },
    { label: '🔐 تعديل صلاحيات',     description: 'تخطي حماية تعديل صلاحيات القنوات',         value: 'permissionEdit',emoji: '🔐' },
    { label: '🤖 إضافة بوت',         description: 'تخطي حماية إضافة البوتات',                 value: 'botAdd',        emoji: '🤖' },
    { label: '⚙️ إعدادات السيرفر',   description: 'تخطي حماية تعديل إعدادات السيرفر',         value: 'guildUpdate',   emoji: '⚙️' },
    { label: '🔨 حظر عضو',           description: 'تخطي حماية الحظر',                         value: 'memberBan',     emoji: '🔨' },
];

const FEATURE_NAMES = Object.fromEntries(FEATURES.map(f => [f.value, f.label]));
const pendingOps = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('التخطي')
        .setDescription('إدارة قائمة التخطي للحماية (للأونرات فقط).')
        .addSubcommand(sub =>
            sub.setName('إضافة')
                .setDescription('إضافة مستخدم لقائمة التخطي')
                .addUserOption(opt =>
                    opt.setName('المستخدم').setDescription('المستخدم المراد إضافته').setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('حذف')
                .setDescription('حذف مستخدم من قائمة التخطي')
                .addUserOption(opt =>
                    opt.setName('المستخدم').setDescription('المستخدم المراد حذفه').setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName('قائمة').setDescription('عرض قائمة التخطي الحالية')
        ),

    getPendingOps: () => pendingOps,
    getFeatureNames: () => FEATURE_NAMES,
    getFeatures: () => FEATURES,

    async execute(interaction, client) {
        const settings = getSettings();
        const lang = getLang();

        if (!settings.owners.includes(interaction.user.id)) {
            return interaction.reply({ content: lang.no_permission, ephemeral: true });
        }

        const sub = interaction.options.getSubcommand();

        // ===== قائمة =====
        if (sub === 'قائمة') {
            await interaction.deferReply({ ephemeral: true });
            const bypasses = await db.getAllBypasses(interaction.guild.id);

            if (!bypasses.length) {
                return interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('📋 قائمة التخطي')
                        .setDescription('> لا يوجد أي مستخدم في قائمة التخطي حالياً.')
                        .setColor('#3498db')
                        .setFooter({ text: '© 2026 CS. جميع الحقوق محفوظة', iconURL: client.user?.displayAvatarURL() })
                    ]
                });
            }

            const grouped = {};
            for (const row of bypasses) {
                if (!grouped[row.userId]) grouped[row.userId] = [];
                grouped[row.userId].push(FEATURE_NAMES[row.feature] || row.feature);
            }

            const desc = Object.entries(grouped)
                .map(([uid, feats]) => `<@${uid}>\n${feats.map(f => `> ${f}`).join('\n')}`)
                .join('\n\n');

            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setTitle('📋 قائمة التخطي')
                    .setDescription(desc.slice(0, 4000))
                    .setColor('#3498db')
                    .setFooter({ text: `${bypasses.length} إدخال • © 2026 CS. جميع الحقوق محفوظة`, iconURL: client.user?.displayAvatarURL() })
                ]
            });
        }

        // ===== إضافة =====
        if (sub === 'إضافة') {
            const target = interaction.options.getUser('المستخدم');
            if (settings.owners.includes(target.id)) {
                return interaction.reply({ content: '❌ لا يمكن إضافة الأونر، فهو مُعفى تلقائياً.', ephemeral: true });
            }

            pendingOps.set(`add:${interaction.user.id}`, { targetId: target.id, targetTag: target.tag });
            setTimeout(() => pendingOps.delete(`add:${interaction.user.id}`), 120000);

            const menu = new StringSelectMenuBuilder()
                .setCustomId(`bypass_add_select:${interaction.user.id}`)
                .setPlaceholder('اختر الميزات التي تريد تخطيها لهذا المستخدم...')
                .setMinValues(1).setMaxValues(FEATURES.length)
                .addOptions(FEATURES);

            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setTitle('➕ إضافة تخطي')
                    .setDescription(`**المستخدم:** ${target} (${target.id})\n\nاختر الميزات التي تريد **تخطي الحماية** عليها لهذا المستخدم:`)
                    .setColor('#2ecc71')
                    .setThumbnail(target.displayAvatarURL())
                    .setFooter({ text: 'تنتهي هذه القائمة خلال دقيقتين', iconURL: client.user?.displayAvatarURL() })
                ],
                components: [new ActionRowBuilder().addComponents(menu)],
                ephemeral: true
            });
        }

        // ===== حذف =====
        if (sub === 'حذف') {
            await interaction.deferReply({ ephemeral: true });
            const target = interaction.options.getUser('المستخدم');
            const userBypasses = await db.getUserBypasses(interaction.guild.id, target.id);

            if (!userBypasses.length) {
                return interaction.editReply({ content: `❌ المستخدم ${target} لا يملك أي تخطي حالياً.` });
            }

            const options = userBypasses.map(f => ({
                ...(FEATURES.find(x => x.value === f) || { label: f, value: f, description: 'ميزة' })
            }));
            options.push({ label: '❌ حذف الكل', description: 'حذف جميع تخطيات هذا المستخدم', value: '__remove_all__', emoji: '❌' });

            pendingOps.set(`remove:${interaction.user.id}`, { targetId: target.id, targetTag: target.tag });
            setTimeout(() => pendingOps.delete(`remove:${interaction.user.id}`), 120000);

            const menu = new StringSelectMenuBuilder()
                .setCustomId(`bypass_remove_select:${interaction.user.id}`)
                .setPlaceholder('اختر التخطيات التي تريد حذفها...')
                .setMinValues(1).setMaxValues(options.length)
                .addOptions(options);

            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setTitle('🗑️ حذف تخطي')
                    .setDescription(
                        `**المستخدم:** ${target} (${target.id})\n\n**تخطياته الحالية:**\n` +
                        userBypasses.map(f => `> ${FEATURE_NAMES[f] || f}`).join('\n')
                    )
                    .setColor('#e74c3c')
                    .setThumbnail(target.displayAvatarURL())
                    .setFooter({ text: 'تنتهي هذه القائمة خلال دقيقتين', iconURL: client.user?.displayAvatarURL() })
                ],
                components: [new ActionRowBuilder().addComponents(menu)]
            });
        }
    }
};
