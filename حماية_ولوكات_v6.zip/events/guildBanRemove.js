// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');

module.exports = {
    name: 'guildBanRemove',
    async execute(ban, client) {
        await sendLog(client, ban.guild.id, 'banLog', {
            title: '✅ تم رفع الحظر عن عضو',
            description: `**المستخدم:** ${ban.user.tag} (${ban.user.id})`,
            thumbnail: ban.user.displayAvatarURL(),
            color: '#00ff00'
        });
    }
};
