// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'roleCreate',
    async execute(role, client) {
        const executor = await getExecutor(role.guild, AuditLogEvent.RoleCreate, role.id);

        if (executor) {
            const blocked = await handleProtection(
                client, role.guild,
                'إنشاء رتبة', 'roleCreate',
                executor, `الرتبة: ${role.name} (${role.id})`,
                async () => { await role.delete('حماية Anti-Nuke').catch(() => {}); }
            );
            if (blocked) return;
        }

        await sendLog(client, role.guild.id, 'roleLog', {
            title: '✨ تم إنشاء رتبة',
            description: `**الرتبة:** ${role} (${role.name})\n**ID:** ${role.id}${executor ? `\n**المنفذ:** ${executor.tag} (${executor.id})` : ''}`,
            color: '#00ff00'
        });
    }
};
