// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
module.exports = {
    name: 'emojiCreate',
    async execute(emoji, client) {
        await sendLog(client, emoji.guild.id, 'emojiLog', {
            title: '✨ تم إضافة إيموجي',
            description: `**الإيموجي:** ${emoji} (${emoji.name})\n**ID:** ${emoji.id}`,
            thumbnail: emoji.url,
            color: '#00ff00'
        });
    }
};
