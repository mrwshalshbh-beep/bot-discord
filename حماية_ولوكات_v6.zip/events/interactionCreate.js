// Copyright (c) 2026 CS. All rights reserved.
module.exports = {
    name: 'interactionCreate',
    async execute(interaction, client) {
        const { getSettings, setSettings, getWebhooks, setWebhooks, getLang } = require('../utils/config.js');
        const db = require('../utils/database.js');

        // =================== سلكت منيو ===================
        if (interaction.isStringSelectMenu()) {
            const settings = getSettings();
            const lang = getLang();

            if (!settings.owners.includes(interaction.user.id)) {
                return interaction.reply({ content: lang.no_permission, ephemeral: true });
            }

            // --- حماية ---
            if (interaction.customId === 'protection_select') {
                const value = interaction.values[0];
                if (value === 'protection_on') {
                    settings.protectionEnabled = true;
                    setSettings(settings);
                    await interaction.update({ content: lang.protection_toggled_on, embeds: [], components: [] });
                } else if (value === 'protection_off') {
                    settings.protectionEnabled = false;
                    setSettings(settings);
                    await interaction.update({ content: lang.protection_toggled_off, embeds: [], components: [] });
                }
                return;
            }

            // --- ويب هوك ---
            if (interaction.customId === 'webhook_type_select') {
                const webhookCmd = require('../commands/ضبط_الويب_هوك.js');
                const pendingUrl = webhookCmd.getPendingWebhooks().get(interaction.user.id);
                if (!pendingUrl) {
                    return interaction.update({ content: '❌ انتهت صلاحية الطلب. أعد الأمر `/ضبط_الويب_هوك`.', embeds: [], components: [] });
                }
                const logType = interaction.values[0];
                const webhooks = getWebhooks();
                webhooks[logType] = pendingUrl;
                setWebhooks(webhooks);
                webhookCmd.getPendingWebhooks().delete(interaction.user.id);

                const logTypeNames = {
                    messageLog:'سجل الرسائل', memberLog:'سجل الأعضاء', roleLog:'سجل الرتب',
                    channelLog:'سجل القنوات', serverLog:'سجل السيرفر', voiceLog:'سجل الصوت',
                    threadLog:'سجل المواضيع', emojiLog:'سجل الإيموجي', banLog:'سجل الباندات',
                    protectionLog:'سجل الحماية'
                };
                const successMessage = lang.webhook_set_success.replace('{type}', logTypeNames[logType] || logType);
                await interaction.update({ content: successMessage, embeds: [], components: [] });
                return;
            }

            // --- إضافة تخطي ---
            if (interaction.customId.startsWith('bypass_add_select:')) {
                await interaction.deferUpdate();
                const bypassCmd = require('../commands/التخطي.js');
                const pendingOps = bypassCmd.getPendingOps();
                const featureNames = bypassCmd.getFeatureNames();
                const op = pendingOps.get(`add:${interaction.user.id}`);
                if (!op) {
                    return interaction.editReply({ content: '❌ انتهت صلاحية الطلب.', embeds: [], components: [] });
                }
                pendingOps.delete(`add:${interaction.user.id}`);

                const selectedFeatures = interaction.values;
                for (const feature of selectedFeatures) {
                    await db.addBypass(interaction.guild.id, op.targetId, feature, interaction.user.id);
                }

                const { EmbedBuilder } = require('discord.js');
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('✅ تم إضافة التخطي')
                        .setDescription(
                            `**المستخدم:** <@${op.targetId}>\n\n**الميزات التي تم تخطيها:**\n` +
                            selectedFeatures.map(f => `> ${featureNames[f] || f}`).join('\n')
                        )
                        .setColor('#2ecc71')
                        .setFooter({ text: '© 2026 CS. جميع الحقوق محفوظة', iconURL: client.user?.displayAvatarURL() })
                    ],
                    components: []
                });
                return;
            }

            // --- حذف تخطي ---
            if (interaction.customId.startsWith('bypass_remove_select:')) {
                await interaction.deferUpdate();
                const bypassCmd = require('../commands/التخطي.js');
                const pendingOps = bypassCmd.getPendingOps();
                const featureNames = bypassCmd.getFeatureNames();
                const op = pendingOps.get(`remove:${interaction.user.id}`);
                if (!op) {
                    return interaction.editReply({ content: '❌ انتهت صلاحية الطلب.', embeds: [], components: [] });
                }
                pendingOps.delete(`remove:${interaction.user.id}`);

                const selectedFeatures = interaction.values;
                let removed = [];
                if (selectedFeatures.includes('__remove_all__')) {
                    await db.removeAllBypasses(interaction.guild.id, op.targetId);
                    removed = ['كل الميزات'];
                } else {
                    for (const feature of selectedFeatures) {
                        await db.removeBypass(interaction.guild.id, op.targetId, feature);
                        removed.push(featureNames[feature] || feature);
                    }
                }

                const { EmbedBuilder } = require('discord.js');
                await interaction.editReply({
                    embeds: [new EmbedBuilder()
                        .setTitle('🗑️ تم حذف التخطي')
                        .setDescription(
                            `**المستخدم:** <@${op.targetId}>\n\n**الميزات المحذوفة:**\n` +
                            removed.map(f => `> ${f}`).join('\n')
                        )
                        .setColor('#e74c3c')
                        .setFooter({ text: '© 2026 CS. جميع الحقوق محفوظة', iconURL: client.user?.displayAvatarURL() })
                    ],
                    components: []
                });
                return;
            }
        }

        // =================== الأوامر ===================
        if (!interaction.isChatInputCommand()) return;

        const command = client.commands.get(interaction.commandName);
        if (!command) return;

        try {
            await command.execute(interaction, client);
        } catch (error) {
            console.error(error);
            const lang = getLang();
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: lang.error_occurred, ephemeral: true });
            } else {
                await interaction.reply({ content: lang.error_occurred, ephemeral: true });
            }
        }
    },
};
