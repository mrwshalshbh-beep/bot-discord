// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'roleDelete',
    async execute(role, client) {
        const executor = await getExecutor(role.guild, AuditLogEvent.RoleDelete, role.id);

        if (executor) {
            const blocked = await handleProtection(
                client, role.guild,
                'حذف رتبة', 'roleDelete',
                executor, `الرتبة: ${role.name} (${role.id})`,
                async () => {
                    await role.guild.roles.create({
                        name: role.name, color: role.color, hoist: role.hoist,
                        permissions: role.permissions, position: role.position,
                        mentionable: role.mentionable,
                        reason: 'حماية Anti-Nuke — إعادة الرتبة المحذوفة'
                    }).catch(() => {});
                }
            );
            if (blocked) return;
        }

        await sendLog(client, role.guild.id, 'roleLog', {
            title: '🗑️ تم حذف رتبة',
            description: `**الرتبة:** ${role.name}\n**ID:** ${role.id}\n**اللون:** ${role.hexColor}${executor ? `\n**المنفذ:** ${executor.tag} (${executor.id})` : ''}`,
            color: '#ff0000'
        });
    }
};
