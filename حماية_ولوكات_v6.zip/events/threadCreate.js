// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
module.exports = {
    name: 'threadCreate',
    async execute(thread, client) {
        await sendLog(client, thread.guild.id, 'threadLog', {
            title: '🧵 تم إنشاء موضوع',
            description: `**الموضوع:** ${thread} (${thread.name})\n**ID:** ${thread.id}\n**القناة الأم:** ${thread.parent || 'غير معروف'}`,
            color: '#00ff00'
        });
    }
};
