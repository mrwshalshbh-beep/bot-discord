// Copyright (c) 2026 CS. All rights reserved.
const { REST, Routes } = require('discord.js');
const { joinVoiceChannel, VoiceConnectionStatus, entersState } = require('@discordjs/voice');
const config = require('../config.js');

// احتفاظ بـ connection مرجع لمنع garbage collection
let voiceConnection = null;

async function joinBotVoiceChannel(client) {
    if (!config.voiceChannelId) return;
    try {
        const channel = await client.channels.fetch(config.voiceChannelId).catch(() => null);
        if (!channel || !channel.isVoiceBased()) {
            console.error('[CS System] القناة الصوتية غير موجودة أو ليست صوتية: ' + config.voiceChannelId);
            return;
        }

        voiceConnection = joinVoiceChannel({
            channelId: channel.id,
            guildId: channel.guild.id,
            adapterCreator: channel.guild.voiceAdapterCreator,
            selfMute: true,
            selfDeaf: true
        });

        // إعادة الانضمام تلقائياً عند الانقطاع
        voiceConnection.on(VoiceConnectionStatus.Disconnected, async () => {
            try {
                await Promise.race([
                    entersState(voiceConnection, VoiceConnectionStatus.Signalling, 5_000),
                    entersState(voiceConnection, VoiceConnectionStatus.Connecting, 5_000),
                ]);
            } catch {
                // إعادة المحاولة بعد 5 ثواني
                setTimeout(() => joinBotVoiceChannel(client), 5000);
            }
        });

        voiceConnection.on(VoiceConnectionStatus.Ready, () => {
            console.log(`[CS System] ✅ البوت متصل بالقناة الصوتية: ${channel.name}`);
        });

    } catch (e) {
        console.error('[CS System] فشل الانضمام للقناة الصوتية:', e.message);
        setTimeout(() => joinBotVoiceChannel(client), 10000);
    }
}

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        console.log(`[CS System] ✅ تم تسجيل الدخول: ${client.user.tag}`);

        // تحديث الأوامر
        const commands = client.commands.map(cmd => cmd.data.toJSON());
        const rest = new REST({ version: '10' }).setToken(config.token);

        try {
            console.log('[CS System] جاري تحديث الأوامر...');
            for (const guild of client.guilds.cache.values()) {
                await rest.put(Routes.applicationGuildCommands(client.user.id, guild.id), { body: [] }).catch(() => {});
            }
            await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
            console.log('[CS System] ✅ تم تحديث الأوامر بنجاح.');
        } catch (error) {
            console.error('[CS System] خطأ في تحديث الأوامر:', error);
        }

        // الانضمام للقناة الصوتية
        await joinBotVoiceChannel(client);
    },
};
