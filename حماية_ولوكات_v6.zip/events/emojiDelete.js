// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
module.exports = {
    name: 'emojiDelete',
    async execute(emoji, client) {
        await sendLog(client, emoji.guild.id, 'emojiLog', {
            title: '🗑️ تم حذف إيموجي',
            description: `**الاسم:** ${emoji.name}\n**ID:** ${emoji.id}`,
            color: '#ff0000'
        });
    }
};
