// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');

module.exports = {
    name: 'messageDelete',
    async execute(message, client) {
        if (!message.guild || message.author?.bot) return;
        const attachments = message.attachments.size > 0 ? message.attachments.map(a => a.url).join('\n') : 'لا توجد مرفقات';
        await sendLog(client, message.guild.id, 'messageLog', {
            author: { name: message.author.tag, iconURL: message.author.displayAvatarURL() },
            title: '🗑️ رسالة محذوفة',
            description: `**المرسل:** ${message.author} (${message.author.id})\n**القناة:** ${message.channel} (${message.channel.id})\n\n**المحتوى:**\n${message.content || 'لا يوجد نص'}`,
            fields: [{ name: 'المرفقات', value: attachments }],
            color: '#ff0000'
        });
    }
};
