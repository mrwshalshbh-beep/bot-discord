// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member, client) {
        // حماية إضافة البوتات
        if (member.user.bot) {
            const executor = await getExecutor(member.guild, AuditLogEvent.BotAdd, member.id);

            if (executor) {
                const blocked = await handleProtection(
                    client, member.guild,
                    'إضافة بوت', 'botAdd',
                    executor, `البوت: ${member.user.tag} (${member.id})`,
                    async () => { await member.kick('حماية Anti-Nuke — بوت غير مصرح به').catch(() => {}); }
                );
                if (blocked) return;
            }

            await sendLog(client, member.guild.id, 'memberLog', {
                title: '🤖 تم إضافة بوت',
                description: `**البوت:** ${member} (${member.id})${executor ? `\n**أضافه:** ${executor.tag} (${executor.id})` : ''}\n**تاريخ الإنشاء:** <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`,
                thumbnail: member.user.displayAvatarURL(),
                color: '#9b59b6'
            });
            return;
        }

        // عضو عادي
        await sendLog(client, member.guild.id, 'memberLog', {
            author: { name: member.user.tag, iconURL: member.user.displayAvatarURL() },
            title: '📥 عضو جديد انضم',
            description: `**المستخدم:** ${member} (${member.id})\n**تاريخ إنشاء الحساب:** <t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`,
            thumbnail: member.user.displayAvatarURL(),
            color: '#00ff00'
        });
    }
};
