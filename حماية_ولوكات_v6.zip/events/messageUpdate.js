// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');

module.exports = {
    name: 'messageUpdate',
    async execute(oldMessage, newMessage, client) {
        if (!newMessage.guild || newMessage.author?.bot) return;
        if (oldMessage.content === newMessage.content) return;
        await sendLog(client, newMessage.guild.id, 'messageLog', {
            author: { name: newMessage.author.tag, iconURL: newMessage.author.displayAvatarURL() },
            title: '✏️ رسالة معدّلة',
            description: `**المرسل:** ${newMessage.author} (${newMessage.author.id})\n**القناة:** ${newMessage.channel} (${newMessage.channel.id})\n\n**قبل:**\n${oldMessage.content || 'لا يوجد'}\n\n**بعد:**\n${newMessage.content || 'لا يوجد'}`,
            color: '#ffa500'
        });
    }
};
