// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildUpdate',
    async execute(oldGuild, newGuild, client) {
        const executor = await getExecutor(newGuild, AuditLogEvent.GuildUpdate, null);

        if (executor) {
            const blocked = await handleProtection(
                client, newGuild,
                'تعديل إعدادات السيرفر', 'guildUpdate',
                executor, `السيرفر: ${newGuild.name} (${newGuild.id})`,
                async () => {
                    await newGuild.edit({
                        name: oldGuild.name,
                        description: oldGuild.description,
                        reason: 'حماية Anti-Nuke'
                    }).catch(() => {});
                }
            );
            if (blocked) return;
        }

        let changes = '';
        if (oldGuild.name        !== newGuild.name)        changes += `**الاسم:** ${oldGuild.name} ➡️ ${newGuild.name}\n`;
        if (oldGuild.description !== newGuild.description) changes += `**الوصف:** ${oldGuild.description || 'لا يوجد'} ➡️ ${newGuild.description || 'لا يوجد'}\n`;
        if (oldGuild.ownerId     !== newGuild.ownerId)     changes += `**الأونر:** <@${oldGuild.ownerId}> ➡️ <@${newGuild.ownerId}>\n`;
        if (!changes) return;

        if (executor) changes += `\n**المنفذ:** ${executor.tag} (${executor.id})`;

        await sendLog(client, newGuild.id, 'serverLog', {
            title: '⚙️ تم تعديل إعدادات السيرفر',
            description: changes,
            thumbnail: newGuild.iconURL(),
            color: '#FFD700'
        });
    }
};
