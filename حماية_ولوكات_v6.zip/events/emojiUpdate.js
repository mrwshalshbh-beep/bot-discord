// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
module.exports = {
    name: 'emojiUpdate',
    async execute(oldEmoji, newEmoji, client) {
        if (oldEmoji.name === newEmoji.name) return;
        await sendLog(client, newEmoji.guild.id, 'emojiLog', {
            title: '✏️ تم تعديل إيموجي',
            description: `**الإيموجي:** ${newEmoji} (ID: ${newEmoji.id})\n**الاسم:** \`${oldEmoji.name}\` ➡️ \`${newEmoji.name}\``,
            thumbnail: newEmoji.url,
            color: '#ffa500'
        });
    }
};
