// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'roleUpdate',
    async execute(oldRole, newRole, client) {
        const nameChanged       = oldRole.name        !== newRole.name;
        const permsChanged      = oldRole.permissions.bitfield !== newRole.permissions.bitfield;
        const colorChanged      = oldRole.hexColor    !== newRole.hexColor;
        const hoistChanged      = oldRole.hoist       !== newRole.hoist;
        const mentionableChanged= oldRole.mentionable !== newRole.mentionable;
        if (!nameChanged && !permsChanged && !colorChanged && !hoistChanged && !mentionableChanged) return;

        const executor = await getExecutor(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id);

        if (executor) {
            const blocked = await handleProtection(
                client, newRole.guild,
                'تعديل رتبة', 'roleUpdate',
                executor, `الرتبة: ${newRole.name} (${newRole.id})`,
                async () => {
                    await newRole.edit({
                        name: oldRole.name, color: oldRole.color, hoist: oldRole.hoist,
                        permissions: oldRole.permissions, mentionable: oldRole.mentionable,
                        reason: 'حماية Anti-Nuke'
                    }).catch(() => {});
                }
            );
            if (blocked) return;
        }

        let description = `**الرتبة:** ${newRole} (${newRole.id})\n`;
        if (executor) description += `**المنفذ:** ${executor.tag} (${executor.id})\n`;
        description += '\n';
        if (nameChanged)        description += `**الاسم:** \`${oldRole.name}\` ➡️ \`${newRole.name}\`\n`;
        if (colorChanged)       description += `**اللون:** \`${oldRole.hexColor}\` ➡️ \`${newRole.hexColor}\`\n`;
        if (permsChanged)       description += `**الصلاحيات:** تم تعديل الصلاحيات\n`;
        if (hoistChanged)       description += `**الظهور المنفصل:** ${oldRole.hoist} ➡️ ${newRole.hoist}\n`;
        if (mentionableChanged) description += `**قابلية الذكر:** ${oldRole.mentionable} ➡️ ${newRole.mentionable}\n`;

        await sendLog(client, newRole.guild.id, 'roleLog', {
            title: '✏️ تم تعديل رتبة',
            description,
            color: '#ffa500'
        });
    }
};
