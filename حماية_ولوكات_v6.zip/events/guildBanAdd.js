// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildBanAdd',
    async execute(ban, client) {
        const executor = await getExecutor(ban.guild, AuditLogEvent.MemberBanAdd, ban.user.id);

        if (executor) {
            const blocked = await handleProtection(
                client, ban.guild,
                'حظر عضو', 'memberBan',
                executor, `المستخدم: ${ban.user.tag} (${ban.user.id})`,
                async () => { await ban.guild.members.unban(ban.user.id, 'حماية Anti-Nuke — رفع الحظر').catch(() => {}); }
            );
            if (blocked) return;
        }

        await sendLog(client, ban.guild.id, 'banLog', {
            title: '🔨 تم حظر عضو',
            description: `**المستخدم:** ${ban.user.tag} (${ban.user.id})\n**السبب:** ${ban.reason || 'لم يُذكر سبب'}${executor ? `\n**المنفذ:** ${executor.tag} (${executor.id})` : ''}`,
            thumbnail: ban.user.displayAvatarURL(),
            color: '#FFD700'
        });
    }
};
