// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');

module.exports = {
    name: 'guildMemberRemove',
    async execute(member, client) {
        const roles = member.roles.cache.filter(r => r.id !== member.guild.id).map(r => r.toString()).join(', ') || 'لا توجد رتب';
        await sendLog(client, member.guild.id, 'memberLog', {
            author: { name: member.user.tag, iconURL: member.user.displayAvatarURL() },
            title: '📤 عضو غادر السيرفر',
            description: `**المستخدم:** ${member.user.tag} (${member.id})\n**الرتب:** ${roles.slice(0, 1000)}`,
            thumbnail: member.user.displayAvatarURL(),
            color: '#ff0000'
        });
    }
};
