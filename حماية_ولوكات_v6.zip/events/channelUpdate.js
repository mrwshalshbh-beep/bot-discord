// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'channelUpdate',
    async execute(oldChannel, newChannel, client) {
        if (!newChannel.guild) return;

        const nameChanged   = oldChannel.name     !== newChannel.name;
        const typeChanged   = oldChannel.type     !== newChannel.type;
        const parentChanged = oldChannel.parentId !== newChannel.parentId;

        const toPermsStr = ch => JSON.stringify(
            [...ch.permissionOverwrites.cache.values()]
                .map(p => ({ id: p.id, allow: p.allow.bitfield.toString(), deny: p.deny.bitfield.toString() }))
                .sort((a, b) => a.id.localeCompare(b.id))
        );
        const permsChanged = toPermsStr(oldChannel) !== toPermsStr(newChannel);

        if (!nameChanged && !typeChanged && !parentChanged && !permsChanged) return;

        const isPermOnly = permsChanged && !nameChanged && !typeChanged && !parentChanged;
        const featureKey  = isPermOnly ? 'permissionEdit' : 'channelUpdate';
        const actionName  = isPermOnly ? 'تعديل صلاحيات قناة' : 'تعديل قناة';
        const auditType   = isPermOnly ? AuditLogEvent.ChannelOverwriteUpdate : AuditLogEvent.ChannelUpdate;

        const executor = await getExecutor(newChannel.guild, auditType, newChannel.id);

        if (executor) {
            const blocked = await handleProtection(
                client, newChannel.guild,
                actionName, featureKey,
                executor, `القناة: ${newChannel.name} (${newChannel.id})`,
                async () => {
                    await newChannel.edit({
                        name: oldChannel.name, parentId: oldChannel.parentId,
                        topic: oldChannel.topic, nsfw: oldChannel.nsfw,
                        reason: 'حماية Anti-Nuke'
                    }).catch(() => {});
                    if (permsChanged) {
                        for (const [, ow] of newChannel.permissionOverwrites.cache)
                            await ow.delete('حماية Anti-Nuke').catch(() => {});
                        for (const [, ow] of oldChannel.permissionOverwrites.cache)
                            await newChannel.permissionOverwrites.create(ow.id,
                                { allow: ow.allow, deny: ow.deny, reason: 'حماية Anti-Nuke — إعادة الصلاحيات' }
                            ).catch(() => {});
                    }
                }
            );
            if (blocked) return;
        }

        let description = `**القناة:** ${newChannel} (${newChannel.id})\n`;
        if (executor)     description += `**المنفذ:** ${executor.tag} (${executor.id})\n`;
        description += '\n';
        if (nameChanged)   description += `**الاسم:** \`${oldChannel.name}\` ➡️ \`${newChannel.name}\`\n`;
        if (parentChanged) description += `**الفئة:** تم التغيير\n`;
        if (permsChanged)  description += `**الصلاحيات:** تم تعديل صلاحيات القناة\n`;

        await sendLog(client, newChannel.guild.id, 'channelLog', {
            title: '✏️ تم تعديل قناة',
            description,
            color: '#ffa500'
        });
    }
};
