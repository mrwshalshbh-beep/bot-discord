// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
const { handleProtection } = require('../utils/protection');
const { getExecutor } = require('../utils/auditLog');
const { AuditLogEvent } = require('discord.js');

const CHANNEL_TYPES = { 0:'نصية',2:'صوتية',4:'فئة',5:'إعلانات',10:'موضوع',11:'موضوع عام',12:'موضوع خاص',13:'مسرح',14:'دليل',15:'فوروم' };

module.exports = {
    name: 'channelCreate',
    async execute(channel, client) {
        if (!channel.guild) return;

        const executor = await getExecutor(channel.guild, AuditLogEvent.ChannelCreate, channel.id);

        if (executor) {
            const blocked = await handleProtection(
                client, channel.guild,
                'إنشاء قناة', 'channelCreate',
                executor, `القناة: ${channel.name} (${channel.id})`,
                async () => { await channel.delete('حماية Anti-Nuke').catch(() => {}); }
            );
            if (blocked) return;
        }

        await sendLog(client, channel.guild.id, 'channelLog', {
            title: '✨ تم إنشاء قناة',
            description: `**القناة:** ${channel} (${channel.name})\n**ID:** ${channel.id}\n**النوع:** ${CHANNEL_TYPES[channel.type] ?? channel.type}${executor ? `\n**المنفذ:** ${executor.tag} (${executor.id})` : ''}`,
            color: '#00ff00'
        });
    }
};
