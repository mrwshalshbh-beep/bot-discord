// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');

module.exports = {
    name: 'voiceStateUpdate',
    async execute(oldState, newState, client) {
        const member = newState.member || oldState.member;
        if (!member || member.user.bot) return;

        if (!oldState.channelId && newState.channelId) {
            await sendLog(client, newState.guild.id, 'voiceLog', {
                author: { name: member.user.tag, iconURL: member.user.displayAvatarURL() },
                title: '🎙️ دخل قناة صوتية',
                description: `**المستخدم:** ${member} (${member.id})\n**القناة:** ${newState.channel} (${newState.channelId})`,
                color: '#00ff00'
            });
        } else if (oldState.channelId && !newState.channelId) {
            await sendLog(client, oldState.guild.id, 'voiceLog', {
                author: { name: member.user.tag, iconURL: member.user.displayAvatarURL() },
                title: '🎙️ غادر قناة صوتية',
                description: `**المستخدم:** ${member} (${member.id})\n**القناة:** ${oldState.channel} (${oldState.channelId})`,
                color: '#ff0000'
            });
        } else if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
            await sendLog(client, newState.guild.id, 'voiceLog', {
                author: { name: member.user.tag, iconURL: member.user.displayAvatarURL() },
                title: '🎙️ انتقل بين القنوات الصوتية',
                description: `**المستخدم:** ${member} (${member.id})\n**من:** ${oldState.channel} (${oldState.channelId})\n**إلى:** ${newState.channel} (${newState.channelId})`,
                color: '#ffa500'
            });
        }
    }
};
