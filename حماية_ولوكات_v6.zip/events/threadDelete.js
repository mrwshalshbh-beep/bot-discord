// Copyright (c) 2026 CS. All rights reserved.
const { sendLog } = require('../utils/logger');
module.exports = {
    name: 'threadDelete',
    async execute(thread, client) {
        await sendLog(client, thread.guild.id, 'threadLog', {
            title: '🗑️ تم حذف موضوع',
            description: `**الاسم:** ${thread.name}\n**ID:** ${thread.id}`,
            color: '#ff0000'
        });
    }
};
